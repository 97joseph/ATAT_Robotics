package chen.ENUMS;

public enum Crewman {Driver("Driver"), Commander("Commander"), Gunner("Gunner");

	private String type;

	Crewman(String tgt) {
	// TODO Auto-generated constructor stub
}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}}

