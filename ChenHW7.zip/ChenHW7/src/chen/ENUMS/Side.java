package chen.ENUMS;

public enum Side {Left, Right}


