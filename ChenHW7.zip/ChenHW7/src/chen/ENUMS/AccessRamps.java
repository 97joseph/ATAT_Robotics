package chen.ENUMS;

public enum AccessRamps {ATAT("Heavy Ramp"), ATST("Soft Ramp");

	private String type;
	
	AccessRamps(String type) {
	// TODO Auto-generated constructor stub
}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}


