package chen.LegSupport;

import chen.ENUMS.Side;

public class LowerLeg {
	String type = "Lower";
	
	public LowerLeg(Side legSide) {

	}
}
