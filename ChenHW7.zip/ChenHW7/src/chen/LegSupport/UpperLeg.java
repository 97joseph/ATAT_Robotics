package chen.LegSupport;

import chen.ENUMS.Side;

public class UpperLeg {
	String type = "Upper";
	
	public UpperLeg(Side legSide) {
		
	}

}
