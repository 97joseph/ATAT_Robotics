package chen.LegSupport;

import chen.ENUMS.Side;

public class FootPad {
	String type = "Pad";
	
	public FootPad(Side legSide) {
		
	}

}
