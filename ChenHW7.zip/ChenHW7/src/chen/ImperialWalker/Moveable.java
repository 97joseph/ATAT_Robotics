package chen.ImperialWalker;


public interface Moveable {
	abstract void moveToPosition(String Position_P); 
		
	

}
