package chen.ImperialWalker;

public interface Combatable {
	abstract void assaultPosition(String Position_P);

}
