package li.ENUMS;

public enum MOS {

	Trooper,
	Demolitions,
	Communications,
	Assault,
	Scout,
	Medical;
}
