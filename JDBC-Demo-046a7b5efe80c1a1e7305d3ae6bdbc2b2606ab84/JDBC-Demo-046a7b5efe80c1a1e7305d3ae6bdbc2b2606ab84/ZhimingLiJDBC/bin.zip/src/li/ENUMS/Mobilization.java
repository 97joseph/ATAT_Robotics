package li.ENUMS;

public enum Mobilization {

	Active,
	Reserve;
}
