package li.ENUMS;

public enum WlkrStatus {

	Operational,
	Damaged,
	Destroyed;
}
