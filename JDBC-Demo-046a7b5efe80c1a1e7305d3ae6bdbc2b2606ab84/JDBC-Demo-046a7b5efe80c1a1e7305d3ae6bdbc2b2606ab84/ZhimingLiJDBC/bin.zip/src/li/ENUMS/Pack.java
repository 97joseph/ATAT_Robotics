package li.ENUMS;

public enum Pack {

	PatrolPack,
	AssaultPack;
}
