package li.ENUMS;

public enum STStatus {

	FullDuty,
	Wounded,
	Killed;
}
