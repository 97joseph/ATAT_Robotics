package li.ENUMS;

public enum Cypher {

	Alpha,
	Omega;
	
}
