package li.ENUMS;

public enum Units {

	Assault_Infantry,
	Infantry,
	Reconnaissance;
}
